import React from 'react';

const Layout: React.FC = ({ children }) => <div>{children}</div>;

export default Layout;
