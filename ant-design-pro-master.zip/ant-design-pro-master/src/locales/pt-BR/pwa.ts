export default {
  'app.pwa.offline': 'Você está offline agora',
  'app.pwa.serviceworker.updated': 'Novo conteúdo está disponível',
  'app.pwa.serviceworker.updated.hint':
    'Por favor, pressione o botão "Atualizar" para recarregar a página atual',
  'app.pwa.serviceworker.updated.ok': 'Atualizar',
};
